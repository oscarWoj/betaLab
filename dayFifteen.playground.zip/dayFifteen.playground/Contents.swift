import UIKit

//Swift Review day three

//Properties

struct Person {
    var clothes: String
    var shoes: String

    func describe() {
        print("I like wearing \(clothes) with \(shoes)")
    }
    
    var age: Int

    var ageInDogYears: Int {
        get {
            return age * 7
        }
    }
    
}

let taylor = Person(clothes: "T-shirts", shoes: "sneakers", age: 12)
let other = Person(clothes: "short skirts", shoes: "high heels", age: 13)
taylor.describe()
other.describe()


taylor.ageInDogYears

/*
 Structs and classes have their own properties, you can attach values to them, but you can also have methods to compute their own values
 */

//Static variables
struct TaylorFan {
    static var favoriteSong = "Look What You Made Me Do"

    var name: String
    var age: Int
}

let fan = TaylorFan(name: "James", age: 25)
print(TaylorFan.favoriteSong)

/*
 Static variables stay the same for all new instances of that property, and cant be changed
 */

//Access control

/*
 Initializing your properties with the following keywords allow them to stop other items from accessing their values:
 
 Public: this means everyone can read and write the property.
 Internal: this means only your Swift code can read and write the property. If you ship your code as a framework for others to use, they won’t be able to read the property.
 File Private: this means that only Swift code in the same file as the type can read and write the property.
 Private: this is the most restrictive option, and means the property is available only inside methods that belong to the type, or its extensions.
 
 */


//Polymorphism and type casting,

class Album {
    var name: String

    init(name: String) {
        self.name = name
    }

    func getPerformance() -> String {
        return "The album \(name) sold lots"
    }
}

class StudioAlbum: Album {
    var studio: String

    init(name: String, studio: String) {
        self.studio = studio
        super.init(name: name)
    }

    override func getPerformance() -> String {
        return "The studio album \(name) sold lots"
    }
}

class LiveAlbum: Album {
    var location: String

    init(name: String, location: String) {
        self.location = location
        super.init(name: name)
    }

    override func getPerformance() -> String {
        return "The live album \(name) sold lots"
    }
}

var taylorSwift = StudioAlbum(name: "Taylor Swift", studio: "The Castles Studios")
var fearless = StudioAlbum(name: "Speak Now", studio: "Aimeeland Studio")
var iTunesLive = LiveAlbum(name: "iTunes Live from SoHo", location: "New York")

var allAlbums: [Album] = [taylorSwift, fearless, iTunesLive]

for album in allAlbums {
    print(album.getPerformance())
}

/*
 Since all the studio and live albums are subclasses of the album class, you can make arrays by declaring them all albums, this is called polymorphism
 */
